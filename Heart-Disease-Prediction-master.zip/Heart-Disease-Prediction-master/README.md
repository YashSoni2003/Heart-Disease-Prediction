# Heart Disease-Prediction
 This is a simple machine learning-powered web app predicts that the person has heart disease or not.
